# Vu, Danny
# dxv5960
# 2019-03-04

#---------#---------#---------#---------#---------#--------#
def constructTransform( w, v, width, height ) :
    
    fx = -min(w)
    fy = -min(v)
    gx = (width)(min(v))
    gy = (height)(min(v))
    sx = ((width)((max(v))-(min(v))/((max(w))-(min(w))
    sy = ((height)((max(v))-(min(v))/((max(w))-(min(w))
    ax = (fx)(sx)+(gx)
    ay = (fy)(sy)+(gy)
    return (ax,ay,sx,sy)

#---------#---------#---------#---------#---------#--------#
def _main() :
  w      = ( -1.0, -2.0, 4.0, 5.0 )
  v      = ( 0.15, 0.15, 0.85, 0.85 )
  width  = 500
  height = 400

  values = constructTransform( w, v, width, height )
  ax, ay, sx, sy = values

  print( f'Values          : {values}' )
  print( f'Test transform  : ax {ax}, ay {ay}, sx {sx}, sy {sy}' )

#---------#
if __name__ == '__main__' :
  _main()

#---------#---------#---------#---------#---------#--------#
